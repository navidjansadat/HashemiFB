package com.omar.aghidah

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface

class MainActivity : android.app.Activity() {
    private val green = Color.rgb(11,43,34)
    private val gold = Color.rgb(201,162,39)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.rgb(247,245,238))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        return root
    }

    private fun text(t:String, size:Float, color:Int=Color.DKGRAY, bold:Boolean=false): TextView {
        val v=TextView(this)
        v.text=t; v.textSize=size; v.setTextColor(color)
        v.gravity=Gravity.CENTER
        v.setPadding(18,14,18,14)
        if(bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        return v
    }

    private fun showHome() {
        val root=base()
        val header=LinearLayout(this)
        header.setBackgroundColor(green); header.gravity=Gravity.CENTER
        header.addView(text("☪  عقیده مسلمان",24,Color.WHITE,true))
        root.addView(header, LinearLayout.LayoutParams(-1,150))

        root.addView(text("آموزش ساده و منظم عقاید اسلامی",18,green,true))
        root.addView(text("مؤلف: عمرمختار هاشمی",16,Color.DKGRAY))

        val scroll=ScrollView(this)
        val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(24,10,24,30)

        val chapters=arrayOf(
            "☝  توحید و شناخت الله متعال",
            "✨  صفات الله متعال",
            "ﷺ  نبوت و پیامبران",
            "👼  فرشتگان",
            "📚  کتاب‌های آسمانی",
            "🌙  روز قیامت و آخرت",
            "⚖  قضا و قدر",
            "❤️  حقیقت ایمان",
            "🕌  عقیده اهل‌سنت و جماعت",
            "❓  پرسش‌های اعتقادی"
        )
        chapters.forEachIndexed { i, c ->
            val b=Button(this); b.text="${i+1}. $c"; b.textSize=16f
            b.setTextColor(green); b.setAllCaps(false)
            b.setOnClickListener { showChapter(i+1,c) }
            box.addView(b, LinearLayout.LayoutParams(-1,70).apply{setMargins(0,6,0,6)})
        }
        scroll.addView(box); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        val bottom=LinearLayout(this); bottom.gravity=Gravity.CENTER
        val about=Button(this); about.text="👤 درباره مؤلف"; about.setAllCaps(false)
        about.setOnClickListener { showAbout() }
        val contact=Button(this); contact.text="📞 ارتباط با ما"; contact.setAllCaps(false)
        contact.setOnClickListener { showContact() }
        bottom.addView(about); bottom.addView(contact)
        root.addView(bottom)
        setContentView(root)
    }

    private fun showChapter(n:Int,title:String) {
        val root=base()
        val top=Button(this); top.text="‹  بازگشت"; top.setTextColor(green); top.setAllCaps(false)
        top.setOnClickListener { showHome() }; root.addView(top)
        root.addView(text(title,22,green,true))
        root.addView(text("فصل $n\n\nمحتوای این فصل در مرحله بعد با استفاده از منابع معتبر عقیدتی حنفی/ماتریدی تنظیم و اضافه خواهد شد.\n\n🔖 امکان نشان‌گذاری و ادامه مطالعه نیز در نسخه بعدی اضافه می‌شود.",18))
        setContentView(root)
    }

    private fun showAbout() {
        val root=base()
        val back=Button(this); back.text="‹  بازگشت"; back.setAllCaps(false); back.setOnClickListener{showHome()}
        root.addView(back)
        root.addView(text("درباره مؤلف",24,green,true))
        root.addView(text("عمرمختار هاشمی\n\nاین برنامه با هدف ارائه مطالب آموزشی در زمینه عقاید اسلامی و آشنایی منظم با مباحث اعتقادی اهل‌سنت تهیه می‌شود.",18))
        setContentView(root)
    }

    private fun showContact() {
        val root=base()
        val back=Button(this); back.text="‹  بازگشت"; back.setAllCaps(false); back.setOnClickListener{showHome()}
        root.addView(back)
        root.addView(text("ارتباط با ما",24,green,true))
        root.addView(text("برای ارتباط با مؤلف و ارسال پیشنهادها و پرسش‌ها، راه‌های ارتباطی در نسخه نهایی این بخش قرار می‌گیرد.",18))
        setContentView(root)
    }
}
